"""
Temporary solution for time of development.
"""


GET_FILESYSTEM_RTYPE = "class"
FS_OPTS = {}
